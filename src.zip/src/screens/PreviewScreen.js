import { useState } from "react";
import {
    ActivityIndicator,
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from "react-native";

import { predictMango } from "../utils/runModel";

export default function PreviewScreen({ navigation, route }) {
  const { image } = route.params;

  const [loading, setLoading] = useState(false);

  async function predict() {
    setLoading(true);

    try {
      const result = await predictMango(image);

      navigation.replace("Result", {
        image,
        result,
      });
    } catch (error) {
      console.log(error);
    }

    setLoading(false);
  }

  return (
    <View style={styles.container}>
      <Image
        source={{ uri: image }}
        style={styles.image}
      />

      <TouchableOpacity
        style={styles.button}
        onPress={predict}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#ffffff" />
        ) : (
          <Text style={styles.text}>
            Predict Mango Variety
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },

  image: {
    flex: 1,
    resizeMode: "contain",
  },

  button: {
    backgroundColor: "#2D6A4F",
    padding: 18,
    margin: 20,
    borderRadius: 12,
    alignItems: "center",
  },

  text: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 18,
  },
});